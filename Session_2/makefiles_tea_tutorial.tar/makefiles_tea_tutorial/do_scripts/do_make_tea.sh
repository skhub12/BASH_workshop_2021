#!/usr/bin/env bash

# This is a bash variable, and we set it to 'input argument 1', passed-in, when running this script
TEMPERATURE=$1

# We know what 'cat file' does
# If we put this in backticks, like so `...`, it is like the command
# is run withint he backticks, and the output is put in place of the command
echo Tea in the bag is `cat tea_bag`

# Here is what we want to do:
#   Search for 'earl gray' (or Earl gray or Earl Gray) in the file
#       If we find it, then we do SOMETHING
#       Else, we do               SOMETHING-ELSE
# There are a number of ways to do it, here is a quick one
grep -q -i 'earl gray' tea_bag # -q -> silent; -i -> case-insensitive search
# $? holds the 'exit code' of the previous bash command, in this case the grep command
# if 'earl gray' string matches in the file tea_bag, $? would have 0 in it, else it would have 1
# How am I supposed to know this you wonder? Please see "man grep" (and look for Exit Status)
# In general, $? is 0 in case of success, and non-zero in case of failure of some kind.
if [[ $? -eq 0 ]]              # $? holds the 'exit code' of the bash command just prior to this, in this case, the grep command
then
    # The tea is Earl Gray
    [[ $TEMPERATURE -lt 90 ]] && echo 'warning: Not an ideal temperature for Earl Gray'
    # This statement above uses the && (the logical and operation) cleverly, to write a more compact if-statement
    # if the [[ check ]] is True, the echo statement will get printed,
    #             ...    is False, logical and will skip running the command after &&
else
    # If it is not earl gray, let's not complain,
    # as long as the temperature is not too low!
    [[ $TEMPERATURE  -lt 70 ]] && echo 'warning: the temperture is too low to brew tea'
fi

# Here comes the final produt
# Let's emulate tea by creating a text file, named, tea, with some tea related text!
echo Enjoy your `cat tea_bag` > tea
echo 'Careful, it is hot.' >> tea # note the >> instead of just >, so we append, to previous line, not overwrite


