#!/usr/bin/env bash

# Check if
grep -q dirty cup
if [ $? -eq 0 ]
then
    echo Cup was indeed dirty
    echo Cleaning
    echo > cup
    touch cup.clean
else
    echo Cup was already clean
    touch cup.clean
fi
