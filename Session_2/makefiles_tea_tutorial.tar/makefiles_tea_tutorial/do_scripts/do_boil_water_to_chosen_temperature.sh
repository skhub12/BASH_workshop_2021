#!/usr/bin/env bash

# the following, two bash variables, the second one set from $1, the first input-argument
minimum_temperature=10
TEMPERATURE=$1

# good practice to have these checks in your code
# Here, $# is a bash variable (built-in) that holds the number of arguments passed to the script
# If it is zero, we remind the user about how to correctly run this script.
if [ $# -eq 0 ]
then
    echo "This script requires at least 1 argument"
    exit 1
fi

# Here is how a function may be defined, here is how to call it
#   Usage: die <errorcode_an_integer> "Some error message"
# We indent to use this to 'exit with an exit code, and an error message'.
die () {
    # return code, argument 1
    # note that $1 == 1st argument, $2 == second argument ....
    # and $@ == all of the arguments (note that arguments, by default, are white-space seperated)
    rc=$1
    # we want to presume the rest of everything after argument 1 to be the message
    # so we do a 'shift' operation to 'drop $1', and the rest of it is now $@
    shift
    echo "warning: $@" # note: $@, after shift, is the "Some error message"
    exit $rc
}

# this is another compact, but less readable way to do 'if-else and die on failure'.
# [[  expression ]]  evaluates to True or False, and || is a logical-OR
# The following says: 'if temperature is greater than a min. temperature' is False, then logical-OR requires bash to run die() function as well.
#                                                                            otherwise, go on (i.e., need not call die())!
[[ $TEMPERATURE -gt $minimum_temperature ]] || die 1 "Temperature specification should at least be $minimum_temperature, for some reason!"

sensed_temperature=`cat water` # read the file water, store contents in a variable
                               # NOTE: we are assuming this file contains only a single number!
# also NOTE: no whitespace before =, otherwise, bash would try to
# execute the command 'sensed_temperature', which may not exist!

echo Current water temperature is $sensed_temperature
if [[ $sensed_temperature -lt $TEMPERATURE ]]
then
    echo Heating it up to $TEMPERATURE
    echo $TEMPERATURE > water
    touch water.${TEMPERATURE}C
else
    echo Cooling it down to $TEMPERATURE
    echo $TEMPERATURE > water
    touch water.${TEMPERATURE}C
fi

